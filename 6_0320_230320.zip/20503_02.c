
task main()
{
		playSound(soundBeepBeep);
		wait1Msec(1000);

		playSound(soundBlip);
		wait1Msec(1000);

		playSound(soundDownwardTones);
		wait1Msec(1000);

		playSound(soundException);
		wait1Msec(1000);

		playSound(soundFastUpwardTones);
		wait1Msec(1000);

		playSound(soundLowBuzz);
		wait1Msec(1000);

		playSound(soundLowBuzzShort);
		wait1Msec(1000);

		playSound(soundShortBlip);
		wait1Msec(1000);

		playSound(soundUpwardTones);
		wait1Msec(1000);

		playSoundFile("Dog bark 1");
		wait1Msec(1000);

		playSoundFile("Dog bark 2");
		wait1Msec(1000);

		playSoundFile("Dog growl");
		wait1Msec(1000);

		playSoundFile("Dog sniff");
		wait1Msec(1000);

		playSoundFile("Backing alert");
		wait1Msec(2000);
}
